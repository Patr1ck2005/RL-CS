

class Brain:
    def __init__(self):
        self.know = None
        self.act = None

    def get_inputs(self, inputs):
        self.know = inputs

    def run(self):
        pass

    def get_outputs(self):
        return self.act

