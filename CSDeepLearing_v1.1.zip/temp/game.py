# 导入玩家类
from Object.player import *
from Object.player import Player
from settings import *

import random
import math

class MainProgramme:
    def __init__(self):
        global_settings = GlobalSettings()
        self.tick_rate = global_settings.tick_rate
        self.tick = None
        self.players = []
        self.player_names = []
        self.player_stats = {}
        self.players_in_fire = []
        # 区别人类对象
        self.human = None
        self.player_size = None
        self.shoot_range = None

    # 初始化游戏程序并且添加玩家对象
    def init(self, player_names: tuple = ('A', 'B', 'human')):
        self.tick = 0
        self.player_names = player_names
        for name in player_names:
            if name == 'human':
                self.human = Player(name, 'blue')
                self.players.append(self.human)
            else:
                self.players.append(Player(name, 'red'))
            # 判断人类玩家
            welcome = f'{name} join the map'
            print(f'{welcome:=^20}')  # 格式化字符串打印提示信息
        # 初始化玩家对象（设置位置等参数
        for player in self.players:
            player.init()

    # 射击效果
    def shoot_attack(self):
        for player in self.players_in_fire:
            x, y = player.position
            k = math.tan(math.radians(player.facing))
            b = y-k*x
            for alive_player in self.players:
                ax, ay = player.position
                if (ax-x)^2+(ay-y)^2 <= self.shoot_range ^2 & (abs(k*ax+b-ay))^2/(1+k^2) <= self.player_size ^2:
                    alive_player.get_hit()
                    break

    # 主循环
    def step(self):
        self.tick += 1
        self.players_in_fire = []
        for player in self.players:
            player.step()
            # 主程序备份玩家状态
            self.player_stats[player.name]: dict = player.get_states()
            # 设置开火玩家列表
            if player.fire:
                self.players_in_fire.append(player.name)
                player.reset_fire()


# 测试草稿区域
if __name__ == '__main__':
    pass
