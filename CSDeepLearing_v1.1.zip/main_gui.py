from Visual.visual import GameGUI

game = GameGUI()

if __name__ == '__main__':
    game.run()
