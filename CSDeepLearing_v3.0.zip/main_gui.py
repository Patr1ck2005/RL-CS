from Visual.visual import GameGUI

gamegui = GameGUI()

if __name__ == '__main__':
    gamegui.run()
