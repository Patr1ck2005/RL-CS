# NEAT-samples

Some samples of code and config files for use with the [NEAT-Python package](https://neat-python.readthedocs.io/en/latest/)

These samples are largely copy and pasted, so if you plan to use these and provide a cite, cite neat-python.
