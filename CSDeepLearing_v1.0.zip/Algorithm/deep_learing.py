

class Brain:
    pass

