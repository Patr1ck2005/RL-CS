from Object.object import Creature
import numpy as np


class Chicken(Creature):
    def __init__(self, name):
        super().__init__(name)


