from Game.game import MainProgramme
from Object.player import Player
from Object.chicken import Chicken


class AimTraining(MainProgramme):
    def __init__(self):
        super().__init__()
        self.n_chicken = 10

    def add_objects(self):
        for i in range(self.n_chicken):
            chicken = Chicken(name=i)
            chicken.spawn()
            self.chickens.append(chicken)
