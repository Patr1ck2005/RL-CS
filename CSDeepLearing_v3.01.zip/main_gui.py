from Visual.visual import GameGUI
from Game.aim_training import AimTraining

gamegui = GameGUI(game=AimTraining())

if __name__ == '__main__':
    gamegui.run()
